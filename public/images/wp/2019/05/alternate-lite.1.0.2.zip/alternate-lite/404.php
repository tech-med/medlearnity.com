<?php

print "this is peag bad!"

?>